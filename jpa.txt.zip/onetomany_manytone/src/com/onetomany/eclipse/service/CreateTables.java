package com.onetomany.eclipse.service;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.onetomany.eclipse.entity.Departments;
import com.onetomany.eclipse.entity.Employees;

public class CreateTables {



   public static void main(String[] args) {
   
   EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "onetomany_manytone" );
   EntityManager entitymanager = emfactory.createEntityManager( );
   entitymanager.getTransaction( ).begin( );

   //Create Employee1 Entity
   Employees employee1 = new Employees();
   employee1.setEname("lucifer");
   employee1.setSalary(450000.0);
   employee1.setDeg("Technical READER");

   //Create Employee2 Entity
   Employees employee2 = new Employees();
   employee2.setEname("satan");
   employee2.setSalary(405000.0);
   employee2.setDeg("Technical READER");

   //Create Employee3 Entity
   Employees employee3 = new Employees();
   employee3.setEname("devil");
   employee3.setSalary(500000.0);
   employee3.setDeg("Technical READER");

   //Store Employee
  

   //Create Employeelist
   List<Employees> emplist = new ArrayList<>();
   emplist.add(employee1);
   emplist.add(employee2);
   emplist.add(employee3);

   //Create Department Entity
   Departments department = new Departments();
   department.setName("Destruction");
   department.setEmployeelist(emplist);
   
   employee1.setDepartment(department);
   employee2.setDepartment(department);
   employee3.setDepartment(department);

   //Store Department
   entitymanager.persist(department);
   
 

   entitymanager.getTransaction().commit();
   entitymanager.close();
   emfactory.close();
   }
}