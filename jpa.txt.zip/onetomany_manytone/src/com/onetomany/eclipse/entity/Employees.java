package com.onetomany.eclipse.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Employees{

   @Id
   @GeneratedValue( strategy= GenerationType.AUTO ) 	
   private int eid;
   private String ename;
   private double salary;
   private String deg;
   
   @ManyToOne (cascade=CascadeType.ALL) 
   private Departments department;

   public Employees(int eid, String ename, double salary, String deg) {
      super( );
      this.eid = eid;
      this.ename = ename;
      this.salary = salary;
      this.deg = deg;
   }

   public Employees( ) {
      super();
   }

   public int getEid( ) {
      return eid;
   }
   
   public void setEid(int eid)  {
      this.eid = eid;
   }

   public String getEname( ) {
      return ename;
   }
   
   public void setEname(String ename) {
      this.ename = ename;
   }

   public double getSalary( ) {
      return salary;
   }
   
   public void setSalary(double salary) {
      this.salary = salary;
   }

   public String getDeg( ) {
      return deg;
   }
   
   public void setDeg(String deg) {
      this.deg = deg;
   }

   public Departments getDepartment() {
      return department;
   }

   public void setDepartment(Departments department) {
      this.department = department;
   }
}
