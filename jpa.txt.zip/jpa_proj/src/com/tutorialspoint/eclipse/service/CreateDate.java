package com.tutorialspoint.eclipse.service;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.tutorialspoint.eclipse.entity.Dateclass;
import com.tutorialspoint.eclipse.entity.Employee;

public class CreateDate {
	
	 @SuppressWarnings("deprecation")
	public static void main( String[ ] args ) {
		   
	      EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "jpa_proj" );
	      
	      EntityManager entitymanager = emfactory.createEntityManager( );
	      entitymanager.getTransaction( ).begin( );

	     Dateclass employee=new Dateclass();
	     employee.setDoj(new java.sql.Date(0));
	     employee.setName("hello23");
	      
	      entitymanager.persist( employee );
	      entitymanager.getTransaction( ).commit( );

	      entitymanager.close( );
	      emfactory.close( );
	   }
}
